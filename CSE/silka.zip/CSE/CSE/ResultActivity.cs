﻿using System;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Widget;


namespace CSE
{
    [Activity(Label = "ResultActivity")]
    public class ResultActivity : Activity
    {
        private TextView ResultOfMatch;
        private Button btn;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.ResultView);

            btn = FindViewById<Button>(Resource.Id.BtnOk);
            ResultOfMatch = FindViewById<TextView>(Resource.Id.txtResult);

            btn.Click += Btn_Click;
        }

        private void Btn_Click(object sender, EventArgs e)
        {
            Finish();

        }

        protected override void OnActivityResult(int requestCode, [GeneratedEnum] Result resultCode, Intent data)
        {
            base.OnActivityResult(requestCode, resultCode, data);
            if (requestCode == 0 && resultCode == Result.Ok)
            {
                string signe = data.GetStringExtra("resultat");

                ResultOfMatch.Text = signe;
            }
        }
    }
}